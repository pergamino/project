Please, note the following :

 - This is a packaged version of Cormas for modelers

 - The Photo and Video tools require to have QuickTime installed on your computer

func_plot <- function(sortie_ipsim,
                      datos_epidemio0,
                      date_floracion,
                      date_ini_cosecha,
                      date_fin_cosecha){

library(ggplot2)
library(tidyverse)
library(plotly)

  
  # Definitions couleurs alertes
  ####################
  col_alerta <- factor(c("Azul","Verde","Amarillo","Naranja","Rojo"),
                       levels=c("Azul","Verde","Amarillo","Naranja","Rojo"))
  
  
  
  # Nb de points a attribuer a la croissance  
  # Jacques - Gregoire
  #########
  load("data_internes/data_creci_quantiles_sans2016_median.rdata")
  
  
  # Datos epidemiologicos
  ###########################
  datos_epidemio0$fecha0 <- as.Date(as.character(datos_epidemio0$fecha),format = "%d/%m/%Y")
  datos_epidemio0$fecha2 <- as.POSIXct(datos_epidemio0$fecha0)
  datos_epidemio0$num_mes <- as.numeric(strftime(datos_epidemio0$fecha2,format="%m"))
  datos_epidemio0$ano <- as.numeric(strftime(datos_epidemio0$fecha2,format="%Y"))
  datos_epidemio0$dia <- as.numeric(strftime(datos_epidemio0$fecha2,format="%d"))
  
  monitoreo_fecha_median <- aggregate(data.frame(Fecha_median=datos_epidemio0$fecha0),
                                      by=list(num_mes=datos_epidemio0$num_mes,ano=datos_epidemio0$ano),
                                      median,na.rm=T)
  
  
  datos_epidemio <- merge(datos_epidemio0,monitoreo_fecha_median,by=c("num_mes","ano"),all=T)
  
  sub <- aggregate(data.frame(incidencia=datos_epidemio$incidencia),
                   by=list(Fecha_median=datos_epidemio$Fecha_median,num_mes=datos_epidemio$num_mes,ano=datos_epidemio$ano),
                   mean,na.rm=T)
  
  # Sorties IPSIM
  #############################
  
  df_data_prono <- merge(sortie_ipsim,sub,by="Fecha_median",all=T)
  
  
  ##########################################
  
  #          DATA VS PRONOSTICS
  
  ##########################################
  df_data_prono$creci_obs <- NA
  df_data_prono$creci_moy_JG <- NA
  
  for(i in 2:nrow(df_data_prono)){
    df_data_prono$creci_obs[i] <- 30*(df_data_prono$incidencia[i]-df_data_prono$incidencia[i-1])/as.numeric(df_data_prono$Fecha_median[i]-df_data_prono$Fecha_median[i-1])
  }                           
  
  for(n in 1: nrow(df_data_prono)){                                        
    df_data_prono$creci_moy_JG[n] <- as.numeric(subset(data_quant,num_mes==df_data_prono$num_mes[n],
                                                       select=paste0("nb_pt_moy_cat",df_data_prono$riesgo[n])))
  }    
  
  
  df_data_prono$incidencia_ipsim_moy_JG <- NA
  
  for(s in 1:nrow(df_data_prono)){
    df_data_prono$incidencia_ipsim_moy_JG[s] <- max(0,df_data_prono$incidencia[s]+df_data_prono$creci_moy_JG[s])
  }
  
  
  # Definition des periodes 
  #################
  # df_inc <- subset(df_data_prono,!is.na(incidencia) | !is.na(incidencia_ipsim_moy_JG))
  date_init <- df_data_prono$Fecha_median[1]
  date_fin <- df_data_prono$Fecha_median[nrow(df_data_prono)]
  
  
  
  # plot des zones d'alertes
  ############
  
  rect0 <- data.frame(xstart = min(date_init,date_floracion), xend = date_floracion,
                      ystart = c(0,5,15,20,30), yend = c(5,15,20,30,(max(35,datos_epidemio$incidencia,na.rm=T))),
                      col = col_alerta)
  
  rect1 <- data.frame(xstart = date_floracion, xend = date_ini_cosecha,
                      ystart = c(0,2.5,5,10,20), yend = c(2.5,5,10,20,(max(35,datos_epidemio$incidencia,na.rm=T))),
                      col = col_alerta)
  
  rect2 <- data.frame(xstart = date_ini_cosecha, xend = date_fin_cosecha,
                      ystart = c(0,5,15,20,30), yend = c(5,15,20,30,(max(35,datos_epidemio$incidencia,na.rm=T))),
                      col = col_alerta)
  
  rect3 <- data.frame(xstart = date_fin_cosecha, xend = max(date_fin,date_fin_cosecha),
                      ystart = c(0,2.5,5,10,20), yend = c(2.5,5,10,20,(max(35,datos_epidemio$incidencia,na.rm=T))),
                      col = col_alerta)
  
  # rect4 <- data.frame(xstart = cosecha2, xend = max(date_fin,cosecha2),
  #                     ystart = c(0,5,15,20,30), yend = c(5,15,20,30,(max(35,datos_epidemio$incidencia,na.rm=T))),
  #                     col = col_alerta)
  
  
  # pour faire les fleches de pronostic
  
  df_data_prono$end30 <- df_data_prono$Fecha_median+30
  
  ###############
  # Estimation JG
  ###############
  ggplot() +
    geom_rect(data=rect0, aes(xmin=xstart, xmax=xend, ymin=ystart,
                              ymax=yend, fill=col, alpha =0.2)) +
    geom_rect(data=rect1, aes(xmin=xstart, xmax=xend, ymin=ystart,
                              ymax=yend, fill=col, alpha =0.2)) +
    geom_rect(data=rect2, aes(xmin=xstart, xmax=xend, ymin=ystart,
                              ymax=yend, fill=col, alpha =0.2)) +
    geom_rect(data=rect3, aes(xmin=xstart, xmax=xend, ymin=ystart,
                              ymax=yend, fill=col, alpha =0.2)) +
    
    scale_fill_manual(values = c("cornflowerblue", "chartreuse2",
                                 "gold1","darkorange","firebrick1"))+
    
    geom_boxplot(data=datos_epidemio, aes(x=Fecha_median, y=incidencia, group=Fecha_median),
                 size=0.75, fill="white",alpha=0.2)+
    geom_point(data=df_data_prono, mapping=aes(x=Fecha_median, y=incidencia), size=4, shape=21) + # , fill="white"
    
    geom_segment(data=df_data_prono, mapping=aes(x=Fecha_median, y=incidencia, 
                                                 xend=end30, yend=incidencia_ipsim_moy_JG), 
                 arrow=arrow(length = unit(3, "mm"),type='closed'), size=1.5, color="red") +
    scale_y_continuous(name = "Incidencia",
                       breaks=seq(0, max(datos_epidemio$incidencia),5))+
    labs(x = "Fecha de monitoreo")+
    scale_x_date(date_labels = "%d/%m/%y",
                 breaks=unique(datos_epidemio$Fecha_median))+
    
    theme_bw()+
    theme(
      legend.position="none",
      panel.grid.minor = element_blank(),
      strip.background = element_blank())+
    theme(legend.title=element_blank())
  
}

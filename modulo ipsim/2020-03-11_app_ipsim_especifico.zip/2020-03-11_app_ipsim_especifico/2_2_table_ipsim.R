func_table_ipsim <- function(sortie_ipsim){
  sortie_ipsim$Fecha_monitoreo <- as.character(sortie_ipsim$Fecha_median)
  sub_sortie_ipsim <- sortie_ipsim[,-1]
  sub_sortie_ipsim2 <- sub_sortie_ipsim[,c(3,1,2)]
  return(sub_sortie_ipsim2)
}
func_table_moulinette <- function(output_moulinette){
  sub_output_moulinette <- output_moulinette[,-c(2,3)]
  return(sub_output_moulinette)
}
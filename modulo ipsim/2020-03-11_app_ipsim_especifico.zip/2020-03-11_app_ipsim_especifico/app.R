###############################
# IPSIM APP (moulinette Meteo)
# Date 19.04.2019
# Autor : Natacha MOTISI
###############################

library(shiny)

source("1_moulinette_meteo.R")
source("1_1_table_moulinette_meteo.R")
source("2_ipsim.R")
source("2_2_table_ipsim.R")
source("3_plot.R")
# source("3_plot_new.R")



ui <- fluidPage(
  titlePanel("Pronostico del riesgo epidemiologico de la roya"),

  sidebarLayout(

  sidebarPanel(


      # Fichier donnees epidemio --------------------
      tabsetPanel(id = "tabset",
                  tabPanel("Download datos",
                           h3("Datos epidemiologicos"),
                           fileInput("file_epid", label="Elija un archivo CSV",
                                     accept = c(
                                       "text/csv",
                                       "text/comma-separated-values,text/plain",
                                       ".csv")
      ),
      
      # Fichier meteo ---------------
      h3("Datos climaticos"),
      fileInput("file_meteo", label="Elija un archivo CSV",
                accept = c(
                  "text/csv",
                  "text/comma-separated-values,text/plain",
                  ".csv")
      )
      ),
      
    # tags$hr(),
             
      # h3("Variables del sistema"),
    tabPanel("Variables del sistema",
      
      selectInput(inputId = "CF",
                  label = "Carga fructifera",
                  choices = c("Alta", "Media","Baja")),
      
      selectInput(inputId = "V",
                  label = "Variedad",
                  choices = c("Susceptible", "Moderamente susceptible", "Resistente")),    

      
      checkboxGroupInput(inputId = "Q", 
                         label = "Mes de aplicacion de quimicos:", 
                         c("Enero"     = "1",
                           "Febrero"   = "2",
                           "Marzo"     = "3",
                           "Abril"     = "4",
                           "Mayo"      = "5",
                           "Junio"     = "6",
                           "Julio"     = "7",
                           "Agosto"    = "8",
                           "Setiembre" = "9",
                           "Octubre"   = "10",
                           "Noviembre" = "11",
                           "Diciembre" = "12")),
    
      selectInput(inputId = "NAd",
                  label = "Nutricion adecuada",
                  choices = c("Si","No")),
      
      selectInput(inputId = "SOMB",
                  label = "Sombra",
                  choices = c("Alta", "Media","Baja o pleno sol")),


  tags$hr(),
    
         dateInput(inputId = "fecha_flo",
                   label = "Fecha de la floracion",
                   value = "2017-04-01"),
         
         dateInput(inputId = "fecha_ini_cosecha",
                   label = "Fecha del inicio de la cosecha",
                   value = "2017-10-01"),
         
         dateInput(inputId = "fecha_fin_cosecha",
                   label = "Fecha de la fin de la cosecha",
                   value = "2018-01-01")
  )
      )
  
),
  
  mainPanel(
    
    # Output: Tabset w/ plot, summary, and table ----
    tabsetPanel(type = "tabs",
                tabPanel("Datos epidemio", tableOutput("table_epid")),
                tabPanel("Clima", tableOutput("table_meteo")),
                tabPanel("Moulinette clima", tableOutput("moulinette")),
                tabPanel("Ipsim", tableOutput("ipsim")),
                tabPanel("Grafico", plotOutput("plot_alerta"), # plotlyOutput("plot_alerta"),
                         # downloadButton("downloadPlot", "Download Plot"),
                         # downloadButton("downloadData", "Download Resultados IPSIM") 
                         # box(title = "Colores de alerta",status="warning",height=350,width=250,
                             img(src = "colorAlertas.png",height=250,width=240)
                         # )
                         )
    )
  )
)
)




server <- function(input, output) {
  
  # DATOS EPIDEMIOLOGICOS -------------
  
  df_epid <- reactive({
    inFile_epid <- input$file_epid
    
    if (is.null(inFile_epid))
      return(NULL)
    
    read.csv(inFile_epid$datapath, header = T)
    
  })
  
  output$table_epid <- renderTable({
    df_epid()
  })
  
  # MOULINETTE METEO ----------------
  
  df_meteo <- reactive({
    inFile_meteo <- input$file_meteo
    
    if (is.null(inFile_meteo))
      return(NULL)
    
    read.csv(inFile_meteo$datapath, header = T)
    
  })
  
  
  output$table_meteo <- renderTable({
    df_meteo()
  })
  
  
  df_moulinette_meteo <- reactive({
    moulinette_meteo(df_meteo(),
                     df_epid())
  })
  
  output$moulinette <- renderTable({ 
    func_table_moulinette(df_moulinette_meteo())
  })
  
  
  # Inputs var del sistema ----------------

  Input_fecha_flo <- reactive({
    input$fecha_flo
  })
  
  Input_fecha_ini_cosecha <- reactive({
    input$fecha_ini_cosecha
  })
  
  Input_fecha_fin_cosecha <- reactive({
    input$fecha_fin_cosecha
  })
  
  Input_carga_fruct <- reactive({
    switch(input$CF,
           "Alta"=1, 
           "Media"=2,
           "Baja"=3)
  })
  
  Input_sombra <- reactive({
    switch(input$SOMB,
           "Alta"=1, 
           "Media"=2,
           "Baja o pleno sol"=3)
  })

  Input_var <- reactive({
    switch(input$V,
           "Susceptible"=1, 
           "Moderamente susceptible"=2, 
           "Resistente"=3)
  })


  
  Input_quimicos <- reactive({
    if (is.null(input$Q)){
      return(NA)
    } else {
      as.vector(as.numeric(input$Q))
      }
  })

  
  Input_nutri_adequada <- reactive({
    switch(input$NAd,
           "Si"=1,
           "No"=2)
  })
  
  # IPSIM ----------------
  
  df_ipsim <- reactive({
    func_ipsim(df_moulinette_meteo(),
               Input_carga_fruct(),
               Input_var(),
               Input_quimicos(),
               Input_nutri_adequada(),
               Input_fecha_flo(),
               Input_fecha_ini_cosecha(),
               Input_fecha_fin_cosecha(),
               Input_sombra())
  })
  
  output$ipsim <- renderTable({
    func_table_ipsim(df_ipsim())
  })
    
  
  # Sorties Graphiques -------------

  # output$plot_alerta <- renderPlotly({
  output$plot_alerta <- renderPlot({
    func_plot(df_ipsim(),
              df_epid(),
              Input_fecha_flo(),
              Input_fecha_ini_cosecha(),
              Input_fecha_fin_cosecha())
  })
  
  # 27/06/2019 : download Data + plot --------------
  
  output$downloadData <- downloadHandler(
    filename =function() {paste(input$CF,"_",input$V,"_",input$Q,"_",input$NAd, ".csv", sep="") },
    content = function(file) {
      write.csv(df_ipsim(), file)
    }
  )
  
  output$downloadPlot <- downloadHandler(
    filename = function() {paste(input$CF,"_",input$V,"_",input$Q,"_",input$NAd, ".png", sep="") },
    content = function(file) {
      ggsave(file,
             plot = func_plot(df_ipsim(),
                              df_epid(),
                              Input_fecha_flo(),
                              Input_fecha_ini_cosecha(),
                              Input_fecha_fin_cosecha()),
             device = "png")

    }
  )
  
}

shinyApp(ui, server)
